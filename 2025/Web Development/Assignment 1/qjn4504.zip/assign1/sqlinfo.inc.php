<?php
    // db credentials
    $sql_host = "webdev.aut.ac.nz";
    $sql_user = "qjn4504";
    $sql_pass = "asvspftxvzaumcotmthzqtmyocerkjm";
    $sql_db = "qjn4504";
?>